# 🚦 Road Traffic Accident EDA — Addis Ababa

An exploratory data analysis of 12,316 road traffic accidents, built as a storytelling walkthrough: **Who → When → Where → Road → Environment → Accident Characteristics → Casualty Characteristics → Cause → Severity**.

Every chart is paired with a plain-language takeaway — not just what the chart shows, but what it means and why it matters — plus statistical significance checks (chi-square tests, Cramer's V) on the key relationships.

## 📊 Key Findings

- Of 12,316 accidents, **84.6% resulted in slight injury, 14.1% serious, and 1.3% (158) fatal**.
- **Single-vehicle accidents are 2.2x more severe** than typical two-vehicle collisions (28.2% vs. 12.8% serious/fatal risk) — the strongest relationship in the dataset (p ≈ 5×10⁻⁶⁵).
- **Unlit roads at night carry roughly double the risk** of daylight accidents (28.1% vs. 14.9%).
- **Under-18 drivers face a 1.5x higher severity risk** than the most experienced 31–50 age group.
- The most *common* cause of accidents (following too closely) is one of the *least* severe; rare causes like overspeeding and overloading are the most dangerous per incident.
- **Pedestrians have the highest fatal rate (2.46%)** of any collision type with a meaningful sample size.

Full narrative and all 22 charts are in [`notebooks/RTA_EDA_Storytelling.ipynb`](notebooks/RTA_EDA_Storytelling.ipynb).

## 📁 Project Structure

```
.
├── notebooks/
│   └── RTA_EDA_Storytelling.ipynb   # Main EDA notebook (runs top-to-bottom, outputs included)
├── data/
│   └── RTA_Dataset.csv              # Raw dataset (12,316 rows × 32 columns)
├── docs/
│   ├── RTA_Cross_Questions_QA.md    # Full project Q&A prep (methodology, stats, limitations)
│   └── Casualty_Class_QA.md         # Deep-dive Q&A on the Casualty Class section
├── requirements.txt
└── README.md
```

## 🗂️ About the Dataset

- **12,316 accident records**, ~30 attributes covering the driver, vehicle, road, environment, and outcome.
- Collected from **Addis Ababa Sub-city police departments**, Ethiopia, from manual records covering **2017–2020**, originally compiled for a master's research project. Publicly available via Kaggle and Mendeley Data.
- No calendar date field is included (only day-of-week and time-of-day), so year-over-year or seasonal trends can't be tested from this data alone.

## 🧹 Data Cleaning Highlights

The raw export has a few quirks that are fixed early in the notebook — worth knowing before you dig in:

- Several casualty-related columns use the literal string `"na"` (not a real missing value pandas recognizes by default) to mean *"no casualty record was captured for this accident"* — relabeled to an explicit `"Not Applicable"` category rather than silently dropped.
- A find-and-replace bug had corrupted the word "stationary" in `Pedestrian_movement`.
- A text-encoding glitch in `Type_of_vehicle` (`?` where a `-` should be).
- One invalid value in `Age_band_of_casualty` (`"5"`, not a real age band) is treated as a genuine missing value.

See `docs/Casualty_Class_QA.md` for a full breakdown of the difference between structural "Not Applicable" values and genuine data-entry errors.

## ▶️ How to Run

```bash
git clone <your-repo-url>
cd <your-repo-name>
pip install -r requirements.txt
jupyter notebook notebooks/RTA_EDA_Storytelling.ipynb
```

The notebook reads `RTA_Dataset.csv` using a relative path — run it from inside `notebooks/` with `data/` one level up, or update the `pd.read_csv(...)` path at the top if you move files around.

## 🛠️ Built With

`pandas` · `numpy` · `matplotlib` · `seaborn` · `scipy` (chi-square significance testing)

## 📄 License

The analysis code and notebook in this repository are shared under the MIT License (see `LICENSE`). The underlying dataset (`data/RTA_Dataset.csv`) is redistributed as originally published for research/educational use — refer to the original Kaggle/Mendeley Data listing for its specific terms if you plan to reuse it elsewhere.
