# Anticipated Cross-Questions & Answers
### Road Traffic Accident (RTA) EDA — Addis Ababa

This is a prep sheet for the Q&A portion of your presentation. Questions are grouped by theme, roughly in the order a lecturer or audience tends to ask them: first about the data itself, then your cleaning choices, then statistical rigor, then "why did you find that," then limitations, then "so what."

Every number below matches what's in the notebook — you can cite them with confidence.

---

## A. About the Dataset

### 1. Where does this data come from, and how large is it?
It's a real-world dataset of **12,316 road traffic accidents**, each with ~30 recorded attributes, collected from **Addis Ababa Sub-city police departments** (Ethiopia) for a master's research project. It was compiled from **manual police records covering 2017–2020**. It's a well-known public dataset (also distributed via Kaggle and Mendeley Data) commonly used for accident-severity classification research.

### 2. Is this data current? Does it reflect today's traffic conditions?
No — it covers **2017–2020**, so it's several years old. Traffic volume, road infrastructure, and vehicle mix in Addis Ababa may have changed since. Treat the findings as a snapshot of that period's accident patterns, not a live picture. This is worth stating up front if asked, rather than implying it's real-time.

### 3. Does this generalize to other cities or countries?
Not directly. This is a **single-city dataset from a specific developing-city context** (mixed vehicle types like Bajaj/tuk-tuks and horse carts, particular road and junction designs, a specific policing/reporting process). The *patterns* (e.g., single-vehicle crashes being more severe, unlit roads being more dangerous) are plausible in other contexts too, but the exact percentages are specific to Addis Ababa and shouldn't be quoted for another city without new data.

### 4. What's the target variable, and why is it so imbalanced (84.6% / 14.1% / 1.3%)?
`Accident_severity` — Slight / Serious / Fatal Injury — is the outcome we're exploring the data against. The imbalance is expected and realistic: most real-world traffic accidents genuinely are minor (fender-benders, low-speed collisions), while fatalities are rare events. This is why the notebook always reports a **"Serious + Fatal" combined risk %** rather than raw counts — comparing a 1.3%-baseline fatal rate across small subgroups is noisy, but combining it with "Serious" gives a more stable, still-meaningful severity signal.

---

## B. Data Cleaning & Preparation Decisions

### 5. Why keep rows with missing values instead of dropping them?
Dropping rows with any missing value would have discarded **most of the dataset** — some columns (`Defect_of_vehicle`, `Service_year_of_vehicle`) are missing 30%+ of values, and with 30 columns, row-wise deletion compounds fast. Instead, the notebook keeps all 12,316 rows and simply **excludes the sparsest columns from deep analysis** while using `.dropna()` only on the *specific* column being charted at that moment. That preserves sample size everywhere it matters (Accident_severity itself is 0% missing).

### 6. Why keep "Unknown" as its own category instead of removing it?
Because "Unknown" is itself informative — it usually means the responding officer couldn't determine or record that detail at the scene, which is different from the value being genuinely missing from the dataset. Removing it silently would misrepresent how much really is known. In the notebook, "Unknown" is *excluded* only from a couple of specific ordered charts (e.g., driver age) where it would break a logical low-to-high ordering, but it's kept everywhere else.

### 7. What was that "?" character in vehicle types, and how did you know it needed fixing?
Values like `Lorry (41?100Q)` are a text-encoding artifact — almost certainly a **dash/hyphen ("-") that got corrupted** during export/encoding, since `41?100Q` only makes sense as a load-capacity range ("41–100 quintals"). It was corrected to `Lorry (41-100Q)`. This kind of fix is a judgment call based on domain logic (vehicle load ranges are always written as X–Y), not a guess — and it only affected the display label, not any underlying analysis.

### 8. Why convert the literal string `"na"` in casualty columns to `"Not Applicable"` instead of a true missing value (NaN)?
Because it isn't the same kind of "missing" as, say, a blank `Educational_level` field. In `Casualty_class`, `Sex_of_casualty`, etc., `"na"` consistently appears wherever an accident's record has no separate casualty entry beyond the driver — it's a **structural "not applicable,"** not a data-entry gap. Relabeling it makes that explicit rather than letting it silently disappear or get miscounted as random missingness. It's then explicitly excluded before any casualty-specific chart.

### 9. Did you check for and remove duplicate records?
Yes — `df.duplicated().sum()` returns **zero** exact duplicate rows across all 12,316 records, so no rows were removed on that basis.

### 10. How did you decide the "Time of day" hour boundaries (Morning/Afternoon/Evening/Night)?
They're standard, intuitive commuting-day boundaries: **Morning 5am–12pm, Afternoon 12–5pm, Evening 5–9pm, Night 9pm–5am** — chosen so "Evening" would isolate the rush-hour spike that shows up clearly in the hourly chart (peaking at 5pm), rather than blending it into a generic "afternoon" bucket. It's a reasonable convention, not the only valid one — using 3-hour bins or sunrise/sunset-based bins would be a legitimate alternative and could shift the exact Night-time risk % slightly.

---

## C. Statistical Rigor

### 11. Are these differences statistically significant, or could they just be random noise?
Good question to ask of any EDA. I ran **chi-square tests of independence** between `Accident_severity` and each major factor. Most of the headline relationships in the notebook *are* statistically significant at conventional thresholds:

| Factor | p-value | Significant (p<0.05)? |
|---|---|---|
| Number of vehicles involved | 8.4 × 10⁻⁶⁴ | ✅ Yes — strongest relationship found |
| Time of day | 8.1 × 10⁻¹⁰ | ✅ Yes |
| Types of Junction | 1.3 × 10⁻⁷ | ✅ Yes |
| Light conditions | 4.6 × 10⁻⁸ | ✅ Yes |
| Under-18 driver (flag vs. rest) | 3.6 × 10⁻⁷ | ✅ Yes |
| Driver age band (overall) | 7.5 × 10⁻⁶ | ✅ Yes |
| Day of week | 4.3 × 10⁻⁶ | ✅ Yes |
| No lighting at night (flag vs. rest) | 5.6 × 10⁻⁶ | ✅ Yes |
| Weather conditions | 4.3 × 10⁻⁴ | ✅ Yes |
| Pedestrian collision (flag vs. rest) | 1.6 × 10⁻³ | ✅ Yes |
| Sex of driver | 0.34 | ❌ No |
| Road surface (wet vs. dry) | 0.46 | ❌ No |
| Overloading (flag vs. rest) | 0.28 | ❌ No |
| Overspeeding (flag vs. rest) | 0.060 | ⚠️ Borderline (just misses 0.05) |

This is genuinely useful: it **confirms** that driver sex and road-surface condition really don't move severity in this data (matching what the descriptive charts already suggested), and it flags that the striking **"overspeeding" and "overloading" percentages, while numerically real, aren't statistically confirmed** — because those categories have very few accidents (n=61 and n=59), so there isn't enough data to rule out chance. Good practice is to present those two specifically as *directional signals worth investigating further*, not proven effects — I'd say that explicitly if asked.

### 12. Some of your risk percentages come from very small groups (n=9 for "With Train," n=12 for "X Shape" junctions, n=59–61 for Overspeeding/Overloading). How much should we trust those?
Not very much on their own — that's a fair challenge. A single-digit or low-double-digit sample size means one or two additional fatal accidents could swing the percentage substantially. The notebook flags this directly next to each such chart ("too small to trust," "min. 50 accidents" filters on the risk charts). The practical rule I used: **only lean on a risk percentage as a real finding if the subgroup has roughly 100+ accidents** (age bands, time-of-day, light conditions, single-vehicle all clear this bar comfortably); anything smaller is reported as suggestive, not conclusive.

### 13. Effect sizes (Cramer's V) all look small — around 0.03 to 0.16 — even where p-values are tiny. Doesn't that mean these findings don't actually matter?
This is the most sophisticated version of the significance question, and it's worth answering carefully rather than defensively. **Yes — every individual factor has a statistically real but practically modest relationship with severity** (by conventional Cramer's V thresholds, 0.16 is still "small," not "moderate" or "strong"). With 12,316 rows, even a small, genuine effect becomes statistically detectable — that's exactly what large samples are for. The honest takeaway isn't "these factors don't matter," it's **"no single factor dominates; severity is the sum of several weak-to-modest push factors stacking up together"** (age, lighting, vehicle count, time of day, junction type). That's actually consistent with the closing "risk factors" chart in the notebook — none of those bars reach 2x the baseline on their own, but several factors coinciding (e.g., a young driver, alone, at night, on an unlit road) would plausibly compound. **Number of vehicles involved has the largest effect size found (V = 0.155)** — it's the single strongest lever in this dataset.

### 14. Correlation isn't causation. How do you know "no lighting" *causes* worse outcomes rather than just being associated with something else — like rural roads or higher speeds?
It doesn't, and the notebook doesn't claim it does — it says "associated with" and "risk factor," not "causes." This is exactly right: unlit roads might overlap with **higher-speed roads, lower-traffic (less enforcement) areas, or road segments with worse geometry** — any of those could be the "real" driver, with lighting just riding along. Confirming causation would need either controlled data (e.g., before/after a specific road gets streetlights) or a multivariate model that controls for speed, road type, and area simultaneously. What EDA *can* responsibly claim is: **these two things reliably co-occur with worse outcomes, which makes lighting a reasonable, testable hypothesis for intervention** — not a proven cause.

### 15. Why stop at EDA — why not build a predictive/ML model?
Two reasons. First, the ask for this deliverable was specifically an exploratory, storytelling analysis for a presentation, not a deployed model. Second, EDA is the right *first* step before modeling anyway — it's what tells you which features are worth including, flags data-quality issues (missingness, the "na" bug, the encoding glitch) that would otherwise corrupt a model silently, and sets a sane baseline (15.4% Serious+Fatal rate) to judge any future model against. A natural next step, and a good one to mention if asked "what's next," is a classification model (e.g., logistic regression or gradient boosting) using these same features, evaluated with F1-score given the class imbalance — this is in fact how most published work on this exact dataset frames the follow-on task.

### 16. Did you check for interactions — e.g., is "Night" really just a proxy for "No lighting," since they overlap?
That's a sharp observation, and yes, they do overlap somewhat (the Time-of-day × Light-conditions heatmap in the notebook shows Night accidents shift toward artificial/no lighting, as expected). They are **not fully redundant** with each other, though: night accidents under working streetlights sit at 16.2% risk, much closer to the daylight baseline (14.9%) than to the unlit-night figure (28.1%) — meaning the specific driver of risk is the *absence of lighting*, not "night" as a broad time window. That said, a rigorous next step would be a multivariate model (e.g., logistic regression with both variables entered together) to formally separate their independent contributions rather than inferring it from a two-way table, and I'd say that openly if pressed further.

---

## D. Interpreting Specific Findings

### 17. 92.9% of drivers in the dataset are male. Does that mean men are worse drivers?
No — and the chi-square test backs that up directly: **`Sex_of_driver` vs. `Accident_severity` is not statistically significant (p = 0.34)**. The 92.9% figure almost certainly reflects who is doing most of the *driving* in Addis Ababa during this period (a composition effect), not a difference in driving outcomes once you are behind the wheel. This dataset has no exposure data (total km driven, number of licensed drivers by sex) to even calculate a rate — only accident *counts*, so no per-driver comparison is possible from this data alone.

### 18. Why is "going straight" the most common vehicle movement in accidents (66.2%)? Shouldn't riskier maneuvers like reversing or turning be more common?
Because "going straight" is simply what a vehicle is doing for the vast majority of any drive — most km driven, most minutes on the road, are spent going straight, not reversing or U-turning. This is a **base-rate effect**: rare maneuvers can have a *higher risk per attempt* while still contributing *fewer total accidents* because they're attempted so much less often. It's the same logic as "most fatal falls happen on stairs, not while skydiving" — stairs just get used enormously more.

### 19. Single-vehicle accidents are more than twice as severe as two-vehicle ones (28.2% vs. 12.8% risk). That seems backwards — shouldn't more vehicles colliding be worse?
It's genuinely counter-intuitive, and it's the strongest statistical relationship in the whole dataset (Cramer's V = 0.155, p ≈ 5×10⁻⁶⁵), so it's a real pattern, not noise. The likely mechanism: a **second vehicle can absorb crash energy** in a typical low-to-moderate-speed collision (a fender-bender is still "2 vehicles"). A **single-vehicle accident usually means losing control** — running off the road, hitting a fixed object (wall, tree, ditch), or a rollover — and those crash types tend to happen at higher relative speed and with less "give" than vehicle-on-vehicle contact. It's consistent with global road-safety research, where single-vehicle run-off-road crashes are a well-documented high-severity category.

### 20. Road surface (wet vs. dry) barely moves severity (84.7% vs. 84.4% slight-injury). Shouldn't wet roads obviously be more dangerous?
You'd expect that, and it's exactly why this is worth calling out as a genuine (if slightly disappointing) finding rather than glossing over it — and the chi-square test confirms it's not just close, it's **not statistically significant at all (p = 0.46)**. The most plausible explanation is **driver compensation**: people visibly slow down and drive more cautiously when they can see the road is wet, which can cancel out the physical loss of tire grip. This is a documented phenomenon in road-safety literature (sometimes called "risk compensation"). It's a good example of why intuition needs to be checked against data before being presented as fact.

### 21. Why do under-18 drivers have a higher severity risk (21.9%) despite presumably driving less overall?
The dataset can't fully explain *why*, only confirm *that* it's a real, statistically significant pattern (p ≈ 3.6×10⁻⁷). The standard explanation in road-safety research — plausible but not provable from this data alone — is **inexperience**: less-developed hazard perception, slower reaction to a developing risky situation, and a higher likelihood of that situation escalating into serious injury rather than being avoided or reduced to a minor scrape. It's worth noting this group is also the *smallest* driver age band (6.7% of all drivers) — so it's a high-risk-per-driver group, not a high-volume one.

### 22. 36% of accidents (4,443 of 12,316) have no distinct casualty record ("Not Applicable"). What does that actually mean, and could it bias the casualty findings?
Honestly, the dataset doesn't specify exactly why — it's most consistent with the accident record simply not having a **separate casualty entry captured beyond the driver/vehicle-level record** (possibly property-only damage, or the casualty details for that entry were never filled in at the station). Because of that ambiguity, the notebook explicitly **excludes** those 4,443 rows from all casualty-specific charts (class, sex, age, pedestrian movement) rather than guessing at what "Not Applicable" implies, and states the 63.9%-of-total sample size up front so the audience knows the denominator. It's a real limitation worth naming rather than hiding: if those 4,443 accidents differ systematically from the recorded-casualty ones, the casualty section could be biased — but there's no way to check that from this data.

### 23. The most common cause ("no distancing," 18.4% of accidents) is one of the least severe (14.3% risk), while rare causes (overspeeding, overloading) are the most severe. Why would that be?
Because **frequency and severity are answering two different questions**: how often does a cause lead to *any* accident, versus how bad is the outcome *when it does*. Following too closely tends to produce low-speed, low-energy rear-end-style contact — annoying and common, rarely catastrophic. **Overspeeding and overloading are rarer precisely because they require a specific decision to drive recklessly** — but when that decision leads to a crash, the extra kinetic energy (speed) or reduced vehicle control (overloading) makes the outcome disproportionately worse. As noted in the significance section above, I'd flag that these two specific causes don't reach statistical significance individually (small n) — the *pattern* (common causes ≠ worst causes) is worth stating cautiously, using overspeeding/overloading as suggestive examples rather than proven ones.

---

## E. Limitations a Critical Reviewer Would Flag

### 24. Could there be reporting bias — e.g., minor accidents underreported, or inconsistent severity labeling between officers?
Very plausibly, and this is a fair critique of *any* police-record dataset, not something specific to this analysis. Minor "slight injury" accidents may be under-reported relative to serious/fatal ones (which are harder to avoid recording), which would inflate the apparent severity of the dataset overall. Similarly, "Slight" vs. "Serious" is a judgment call made by different officers at different scenes, and there's no way to audit consistency from the data alone. This doesn't necessarily invalidate the *relative* comparisons (e.g., Night vs. Morning risk) if the reporting bias is roughly consistent across time/place — but it's a real caveat on the *absolute* 84.6% / 14.1% / 1.3% split.

### 25. Is there any seasonal or yearly trend you're missing, since there's no date column?
Correct — the dataset has `Day_of_week` and `Time` but **no year or calendar date**, so it's impossible to check for seasonal patterns (e.g., rainy season vs. dry season) or year-over-year trends within the 2017–2020 window this data spans. If that level of granularity mattered for the audience's purposes, it would need to be requested from the original data source, which isn't available in this export.

### 26. Could the "Unknown" category (12.6% of driver age, similar shares elsewhere) be hiding a systematic pattern rather than being random?
Possibly — this is a legitimate concern with any "Unknown" bucket. If, for example, officers were more likely to record "Unknown" specifically for hit-and-run cases (where the driver isn't present to ask), then "Unknown" wouldn't be random at all, and excluding it from age-based charts could subtly skew the comparison. The notebook doesn't attempt to test this (there isn't a clean way to from the available columns), but it's worth naming as an assumption: the current analysis treats "Unknown" as *if* it were reasonably random noise, which may not fully hold.

### 27. The dataset is 5+ years old at minimum. How relevant is it today?
It should be presented as a **historical case study**, not a live dashboard. Traffic infrastructure (new roads, added streetlights), vehicle mix, and enforcement practices in Addis Ababa may well have shifted since 2017–2020. The *qualitative* patterns (single-vehicle crashes being severe, unlit roads being dangerous, young/inexperienced drivers being higher-risk) are the kind of road-safety findings that tend to be durable across time and geography — but the specific percentages shouldn't be assumed to hold exactly today without newer data.

---

## F. "So What" — Recommendations & Extensions

### 28. If you had to give ONE recommendation to the city based on this analysis, what would it be?
**Street lighting on currently-unlit road segments**, specifically where night-time accident volume is already non-trivial. It's the most *actionable* finding in the dataset — driver behavior (speed, following distance, attentiveness) is hard to change directly, but **infrastructure is a policy lever a city can actually pull**, and the effect size here is large and directionally clear (28.1% vs. 14.9% risk, statistically significant at p ≈ 10⁻⁶). It wouldn't address the majority of accidents (unlit-night crashes are only 1.6% of the total), but it targets a segment where the *danger per accident* is roughly double the baseline — a targeted, cost-bounded intervention rather than a sweeping one.

### 29. How would you extend this into a predictive model?
The natural next step is a multi-class classifier predicting `Accident_severity` from the other ~30 features — this is in fact the standard task researchers have used this exact dataset for. Practical considerations: (1) the severe class imbalance (1.3% fatal) means accuracy is a misleading metric — **F1-score or recall on the minority classes** is more appropriate; (2) techniques like SMOTE/class-weighting would likely be needed given how rare "Fatal" is; (3) the multivariate model would also directly answer the "interaction effects" and "causation vs. correlation" questions above, by estimating each feature's contribution *while holding the others constant* — something this EDA, by design, doesn't do.

### 30. What additional data would make this analysis stronger?
Three things would add the most value: **(1) an actual calendar date**, to check seasonal/yearly trends and control for possible infrastructure changes over the 2017–2020 window; **(2) exposure/denominator data** (e.g., total traffic volume by hour, or licensed drivers by age/sex), which would let us calculate true *rates* instead of just *accident counts* — critical for questions like "are young drivers really riskier, or are there just proportionally more of them driving"; and **(3) precise GPS location** rather than the broad "Area" category, which would allow real geospatial hotspot mapping instead of category-level comparison.
