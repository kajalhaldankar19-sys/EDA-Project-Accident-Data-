# Casualty Class — Anticipated Q&A (Basics → Advanced)
### Your section of the RTA EDA presentation

All numbers below are computed directly from the dataset — you can quote them with confidence.

---

## 🟢 SECTION 1 — Basics

### Q1. What is the `Casualty_class` column, and what values does it contain?
It records **who the injured/affected person was** in each accident — their role, not their identity. It has three real categories plus one placeholder:
- **Driver or rider**
- **Pedestrian**
- **Passenger**
- **"Not Applicable"** (originally stored as the string `"na"` — explained in detail below)

### Q2. What does each row in this column actually represent?
Each row is **one accident record**, and `Casualty_class` tells you the role of the (main) casualty tied to that specific accident — not a count of all people involved.

### Q3. What's the full breakdown of `Casualty_class`, out of all 12,316 accidents?

| Category | Count | % of all 12,316 accidents |
|---|---|---|
| Driver or rider | 4,944 | 40.14% |
| **Not Applicable** | 4,443 | 36.08% |
| Pedestrian | 1,649 | 13.39% |
| Passenger | 1,280 | 10.39% |

### Q4. What does "Not Applicable" mean here?
It means **this accident record has no distinct casualty entry** beyond the driver/vehicle-level details — i.e., the dataset simply didn't capture a separate "who was hurt" entry for that accident. It is **not** one of the three real casualty roles; it's a placeholder meaning "no casualty-role data available for this row."

### Q5. So how many accidents actually have usable casualty data?
**7,873 of 12,316 (63.92%)**. That's the denominator used for every casualty-class percentage and chart in this section — always state it, since "62.8% are Driver or rider" only makes sense relative to that 7,873, not the full 12,316.

---

## 🟡 SECTION 2 — The NaN / "Unknown" Values (the part you specifically asked about)

This is worth understanding precisely, because **there are two genuinely different kinds of "missing" in this section**, and a sharp lecturer may test whether you can tell them apart.

### Q6. The raw data has the literal value `"na"` — isn't that automatically treated as missing (NaN) by pandas?
**No — and this is a subtle, important point.** `pandas.read_csv()` only auto-converts a specific default list of tokens to NaN: things like `NaN`, `NA`, `N/A`, `null`, `None`, and empty cells. **Plain lowercase `"na"` (just two letters, no slash) is *not* in that default list.** So when this file is loaded, that `"na"` stays as a literal text string — it shows up in `.value_counts()` right alongside "Driver or rider" as if it were a real category, not as a missing value. I verified this directly: `df['Casualty_class'].isna().sum()` returns **0** — pandas sees zero missing values in the raw column, because they're all disguised as the string `"na"`.

### Q7. Then why did you rename `"na"` to `"Not Applicable"` instead of just converting it to true NaN?
Two reasons:
1. **It communicates *what kind* of missing this is.** A true NaN usually means "we don't know" (a data-entry gap). Here, `"na"` consistently means "there was nothing to record" — a **structural** absence, not an unknown value. "Not Applicable" says that explicitly; a bare NaN wouldn't.
2. **It prevents it from silently vanishing.** If I'd converted it to true NaN, functions like `value_counts()` (which excludes NaN by default) would hide it entirely — someone skimming the output might not realize 36% of the dataset has no casualty entry at all. Keeping it as a visible, explicit category forces that fact to stay in view.

### Q8. Why did you keep those 4,443 rows at all — why not just drop them from the dataset?
Because **they're valid accident records** — they have complete data for every *other* column (weather, road, time, driver info, `Accident_severity`, etc.). Dropping them would throw away 36% of the entire dataset for no reason outside this one section. Instead, the fix is scoped: **only the casualty-class chart filters them out**, using `df_clean[df_clean['Casualty_class'] != 'Not Applicable']`, and every other section of the analysis (Who, When, Where, Severity, etc.) still uses the full 12,316 rows.

### Q9. Are all the "missing" values in this section the same kind of missing?
**No — this is the key distinction.** There are two separate issues, and they need separate handling:

| Type | Example | Count | What it means | How it was handled |
|---|---|---|---|---|
| **Structural "Not Applicable"** | `Casualty_class = "na"` | 4,443 rows (36.08% of all data) | No casualty entry exists for this accident at all | Relabeled to `"Not Applicable"`, excluded only from casualty-specific charts |
| **Genuine data error** | `Age_band_of_casualty = "5"` | 244 rows (3.10% of the 7,873 *casualty* rows) | An invalid age-band code that isn't a real category (real ones are "Under 18," "18-30," "31-50," "Over 51") | Converted to a true NaN, since this genuinely is unknown/invalid — no way to guess what age band "5" was supposed to mean |

The first is "there's nothing here by design." The second is "there's something wrong here by mistake." Treating them the same way (either dropping both, or keeping both as one blanket "Unknown" bucket) would blur two very different data-quality stories.

### Q10. Did excluding "Not Applicable" rows bias the severity findings in this section?
Good challenge to preempt — I checked this directly rather than assuming it's fine. I compared `Accident_severity` between the 7,873 "has casualty record" rows and the 4,443 "Not Applicable" rows:

| Group | Fatal % | Serious % | Slight % |
|---|---|---|---|
| Has casualty record (n=7,873) | 1.40% | 14.34% | 84.26% |
| Not Applicable (n=4,443) | 1.08% | 13.82% | 85.10% |

A chi-square test confirms these two groups are **not statistically different** (χ² = 3.00, p = 0.22). In plain terms: **the "Not Applicable" accidents aren't secretly worse or better than the accidents with a recorded casualty** — so filtering them out for this section's charts doesn't appear to introduce a severity bias, even though we can't know *why* they're missing.

---

## 🟠 SECTION 3 — Interpreting the Distribution (Intermediate)

### Q11. Why is "Driver or rider" the *largest* casualty class (62.8% of recorded casualties)? Shouldn't a "casualty" be a victim, not the driver?
The drivers themselves can absolutely be casualties — they're just as capable of being injured as anyone else in the vehicle, especially in single-vehicle or high-speed crashes. `Casualty_class` records *role in the accident*, not *fault* — being the driver doesn't exempt you from being hurt. Given that virtually every accident record has a driver but not every accident has a passenger or a pedestrian nearby, it makes sense that "Driver or rider" is the largest single category.

### Q12. What's the breakdown by sex and age within the recorded casualties?
- **Sex:** Male 66.72% (5,253), Female 33.28% (2,620)
- **Age band:** 18–30 → 41.22% (3,145), 31–50 → 32.18% (2,455), Under 18 → 13.57% (1,035), Over 51 → 13.03% (994)

This closely mirrors the driver-age skew from the "Who" section (18–30 and 31–50 also dominate there) — consistent with the idea that the demographic doing most of the driving is also the demographic most often hurt, whether as drivers, passengers, or pedestrians in the same traffic.

### Q13. Does the casualty's *role* (driver / passenger / pedestrian) actually change how severe their injury tends to be?

| Casualty Class | Fatal % | Serious % | Slight % | Combined Serious+Fatal risk |
|---|---|---|---|---|
| Driver or rider | 1.44% | 14.54% | 84.02% | 15.98% |
| Pedestrian | 1.64% | 13.83% | 84.54% | 15.46% |
| Passenger | 0.94% | 14.22% | 84.84% | 15.16% |

**Barely.** The three groups land within about 1 percentage point of each other on combined risk. Pedestrians do have the *highest fatal rate specifically* (1.64%), which lines up with the "pedestrians are the most vulnerable in a collision" finding from the Accident Characteristics section — but as a full severity profile, role alone doesn't move the needle much. (Statistical test below confirms this isn't just eyeballing it.)

### Q14. How does this compare to the overall driver population from the "Who" section?
Overall drivers are 92.9% male; recorded casualties are a less lopsided 66.7% male — meaning **female involvement, while still a minority, is proportionally higher among casualties than among drivers.** That's consistent with passengers and pedestrians (who are more sex-balanced groups than "who drives") making up over a third of all casualties.

---

## 🔴 SECTION 4 — Advanced: Statistics, Bias, and What You'd Improve

### Q15. Is the relationship between `Casualty_class` and `Accident_severity` statistically significant, or does it just look flat by eye?
I ran a chi-square test of independence to check formally:

**χ² = 3.23, degrees of freedom = 4, p = 0.52, Cramer's V = 0.014 (n = 7,873)**

This is **not statistically significant** (p is nowhere near the conventional 0.05 threshold), and the effect size (Cramer's V ≈ 0.01) is close to zero. This *confirms* what the table in Q13 suggested visually: **casualty role genuinely does not predict severity in this dataset.** This is a good, honest finding to state directly rather than searching for a pattern that isn't there — what determines severity (from the rest of the presentation) is the *situation* — time of day, lighting, single-vehicle vs. multi-vehicle — not *who* the casualty was.

### Q16. Isn't `Casualty_severity` basically the same thing as `Accident_severity`? Why do we need both?
They look similar but operate at **different levels and different scales**:
- `Accident_severity` — one value **per accident** (12,316 total), three categories: Slight / Serious / Fatal Injury.
- `Casualty_severity` — one value **per casualty record** (only populated for the 7,873 rows with an actual casualty), coded numerically as **1 / 2 / 3** (raw counts: 3 → 7,076 rows, 2 → 771 rows, 1 → 26 rows), following the same "1 = most severe" convention common in traffic-police coding (1≈Fatal, 2≈Serious, 3≈Slight). It's a **finer-grained, casualty-level severity tag** that isn't always identical to the accident-level label, since one accident's overall severity is presumably driven by its worst outcome, while `Casualty_severity` describes that one specific person's outcome. This notebook uses `Accident_severity` as the primary target throughout for consistency (it's complete for all 12,316 rows), and treats `Casualty_severity` as a secondary, more granular field that's out of scope for the main story — worth mentioning if asked "did you check X" so it's clear it wasn't overlooked, just deliberately not the focus.

### Q17. Could the 36% "Not Applicable" rate reflect a systematic gap in how the police recorded data, rather than random chance?
Very plausibly, and it's worth naming as a limitation rather than a settled fact. Possible explanations include: officers only filling in full casualty detail for the injured party they interacted with directly, incomplete forms for lower-severity call-outs, or a records-digitization gap where some fields were never transcribed. **We can't distinguish between these from the data alone** — there's no linked field (like "reason casualty not recorded") to check. The reassuring part (Q10) is that whatever caused it doesn't appear to correlate with the accident being more or less severe — but it *could* still correlate with something else not tested here (e.g., which sub-city or which reporting officer filed it).

### Q18. If this dataset were being used to train a machine learning model, how would you handle `Casualty_class` and its "Not Applicable"/NaN values differently?
A few options, depending on the modeling goal:
- If predicting `Accident_severity` for **all** accidents (including ones with no casualty detail), `Casualty_class` would need to either be **dropped as a feature** (since it's missing for 36% of rows and leaks information only available *after* the fact) or **one-hot encoded with "Not Applicable" as its own valid category**, letting the model learn from it rather than imputing something fabricated.
- The genuine NaNs (like the `Age_band_of_casualty` "5" error) should **never be imputed with a guessed value** — better to either exclude those specific rows from that one feature or add a `missing_flag` column, since inventing an age band would introduce fake signal.
- Critically: `Casualty_class`, `Sex_of_casualty`, etc. are **only known after an accident has already happened and been fully investigated** — using them to predict `Accident_severity` risks **information leakage** if the goal is a real-time prediction tool (e.g., predicting severity *before* full casualty details are known). Worth flagging this if the conversation moves toward "how would you productionize this."

### Q19. What would you recommend to improve data quality for this specific field going forward?
Two concrete, low-effort fixes: **(1) standardize missing-value encoding** — use pandas' actual recognized NA tokens (or better, leave truly blank) instead of ad hoc strings like `"na"`, so tools don't silently misread 36% of a column as a real category; and **(2) add a reason code** for why casualty detail is absent (e.g., "no injury reported," "not captured at scene," "pending report") — that single addition would convert today's ambiguous "Not Applicable" into something we could actually analyze and trust.
